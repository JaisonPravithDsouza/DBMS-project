from django.apps import AppConfig


class WardConfig(AppConfig):
    name = 'ward'
