from django.apps import AppConfig


class NurseConfig(AppConfig):
    name = 'nurse'
